﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using System.IO;

namespace Interview
{
    public class Reader
    {
        public void Reader_json()
        {
            using (StreamReader r = new StreamReader("data.json"))
            {
                string json = r.ReadToEnd();
                List<Item> items = JsonConvert.DeserializeObject<List<Item>>(json);
            }
        }
    }

        public class Item
        {
        public string id;
        public int ApplicationId;
        public string Type;
        public string Summary;
        public float Amount;
        public DateTime PostingDate;
        public Boolean IsCleared;
        public DateTime ClearedDate;
        }
    
}